package com.etecja.tccfeatures;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TccFeaturesApplicationTests {

	@Test
	void contextLoads() {
	}

}
