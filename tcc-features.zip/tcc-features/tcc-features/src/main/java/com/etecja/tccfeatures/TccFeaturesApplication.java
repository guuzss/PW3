package com.etecja.tccfeatures;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TccFeaturesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TccFeaturesApplication.class, args);
	}

}
